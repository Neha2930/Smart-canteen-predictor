"""
Preprocessing Pipeline for Smart Canteen Food Waste Predictor
Handles data cleaning, missing value imputation, duplicate removal,
feature engineering (temporal, attendance ratios, lag features),
leakage-free encoding and scaling, and time-aware train/test splitting.
"""

import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer

# Numerical features used for regression and classification
NUMERICAL_FEATURES = [
    "campus_attendance",
    "hostel_residents_present",
    "prev_day_demand",
    "rolling_avg_7d",
    "temperature_c",
    "attendance_ratio",
    "hostel_ratio",
    "is_weekend",
    "is_holiday",
    "is_exam_period",
    "day_num",
    "month"
]

# Categorical features
CATEGORICAL_FEATURES = [
    "day_of_week",
    "weather_condition",
    "event_scheduled",
    "menu_specialty"
]

ALL_FEATURE_COLS = NUMERICAL_FEATURES + CATEGORICAL_FEATURES

def clean_and_feature_engineer(df_input):
    """
    Cleans raw data and extracts essential temporal and operational features.
    Handles missing values, duplicates, and type casting safely.
    """
    df = df_input.copy()
    
    # 1. Deduplication
    df = df.drop_duplicates()
    
    # 2. Date parsing and sorting
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
        df = df.sort_values("date").reset_index(drop=True)
        
        # Temporal features
        if "day_of_week" not in df.columns or df["day_of_week"].isnull().any():
            df["day_of_week"] = df["date"].dt.day_name()
        if "day_num" not in df.columns:
            df["day_num"] = df["date"].dt.weekday
        if "month" not in df.columns:
            df["month"] = df["date"].dt.month
        if "year" not in df.columns:
            df["year"] = df["date"].dt.year
        if "is_weekend" not in df.columns:
            df["is_weekend"] = (df["day_num"] >= 5).astype(int)
    else:
        # Default fallback if date column is missing
        if "day_num" not in df.columns:
            df["day_num"] = 0
        if "month" not in df.columns:
            df["month"] = 1
        if "is_weekend" not in df.columns:
            df["is_weekend"] = 0
            
    # 3. Categorical standardizations and imputation
    if "weather_condition" not in df.columns:
        df["weather_condition"] = "Sunny"
    df["weather_condition"] = df["weather_condition"].fillna("Sunny").astype(str)
    
    if "event_scheduled" not in df.columns:
        df["event_scheduled"] = "None"
    df["event_scheduled"] = df["event_scheduled"].fillna("None").astype(str)
    
    if "menu_specialty" not in df.columns:
        df["menu_specialty"] = "Regular Thali"
    df["menu_specialty"] = df["menu_specialty"].fillna("Regular Thali").astype(str)
    
    if "day_of_week" not in df.columns:
        df["day_of_week"] = "Monday"
    df["day_of_week"] = df["day_of_week"].fillna("Monday").astype(str)
    
    # 4. Numerical imputation
    # Campus attendance
    if "campus_attendance" not in df.columns:
        df["campus_attendance"] = 2000
    df["campus_attendance"] = pd.to_numeric(df["campus_attendance"], errors="coerce").fillna(2000)
    
    if "hostel_residents_present" not in df.columns:
        df["hostel_residents_present"] = 900
    df["hostel_residents_present"] = pd.to_numeric(df["hostel_residents_present"], errors="coerce").fillna(900)
    
    if "temperature_c" not in df.columns:
        df["temperature_c"] = 28.0
    df["temperature_c"] = pd.to_numeric(df["temperature_c"], errors="coerce").fillna(28.0)
    
    if "is_holiday" not in df.columns:
        df["is_holiday"] = 0
    df["is_holiday"] = pd.to_numeric(df["is_holiday"], errors="coerce").fillna(0).astype(int)
    
    if "is_exam_period" not in df.columns:
        df["is_exam_period"] = 0
    df["is_exam_period"] = pd.to_numeric(df["is_exam_period"], errors="coerce").fillna(0).astype(int)
    
    # Lag and rolling features
    if "actual_meals_served" in df.columns and ("prev_day_demand" not in df.columns or df["prev_day_demand"].isnull().any()):
        df["prev_day_demand"] = df["actual_meals_served"].shift(1)
        df["prev_day_demand"] = df["prev_day_demand"].bfill().fillna(df["actual_meals_served"].median())
    elif "prev_day_demand" not in df.columns:
        df["prev_day_demand"] = df["campus_attendance"] * 0.55
    df["prev_day_demand"] = pd.to_numeric(df["prev_day_demand"], errors="coerce").fillna(df["campus_attendance"] * 0.55)
    
    if "actual_meals_served" in df.columns and ("rolling_avg_7d" not in df.columns or df["rolling_avg_7d"].isnull().any()):
        df["rolling_avg_7d"] = df["actual_meals_served"].rolling(window=7, min_periods=1).mean()
    elif "rolling_avg_7d" not in df.columns:
        df["rolling_avg_7d"] = df["prev_day_demand"]
    df["rolling_avg_7d"] = pd.to_numeric(df["rolling_avg_7d"], errors="coerce").fillna(df["prev_day_demand"])
    
    # Ratios
    df["attendance_ratio"] = df["campus_attendance"] / 3500.0
    df["hostel_ratio"] = df["hostel_residents_present"] / (df["campus_attendance"] + 1e-5)
    
    # Waste metrics sanity if present
    if "meals_prepared" in df.columns and "actual_meals_served" in df.columns:
        if "food_waste_kg" not in df.columns:
            unserved = (df["meals_prepared"] - df["actual_meals_served"]).clip(lower=0)
            df["food_waste_kg"] = (unserved * 0.42 + 12.0).round(1)
        if "waste_percentage" not in df.columns:
            total_kg = (df["meals_prepared"] * 0.42 + 12.0)
            df["waste_percentage"] = ((df["food_waste_kg"] / total_kg) * 100).round(2)
        if "waste_risk_level" not in df.columns:
            df["waste_risk_level"] = np.where(
                df["waste_percentage"] < 7.5, "Low",
                np.where(df["waste_percentage"] < 16.0, "Medium", "High")
            )
            
    return df

def build_preprocessor_pipeline():
    """
    Creates a scikit-learn ColumnTransformer for scaling numerical features
    and one-hot encoding categorical features without data leakage.
    """
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), NUMERICAL_FEATURES),
            ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), CATEGORICAL_FEATURES)
        ],
        remainder="drop"
    )
    return preprocessor

def prepare_regression_data(df, test_size=0.2, time_aware=True):
    """
    Prepares training and testing sets for Regression (predicting actual_meals_served).
    Uses time-aware chronological split to prevent temporal leakage.
    """
    df_clean = clean_and_feature_engineer(df)
    
    X = df_clean[ALL_FEATURE_COLS].copy()
    y = df_clean["actual_meals_served"].values
    
    n_samples = len(df_clean)
    if time_aware:
        split_idx = int(n_samples * (1 - test_size))
        X_train_raw = X.iloc[:split_idx]
        X_test_raw = X.iloc[split_idx:]
        y_train = y[:split_idx]
        y_test = y[split_idx:]
        split_date = df_clean["date"].iloc[split_idx] if "date" in df_clean.columns else None
    else:
        from sklearn.model_selection import train_test_split
        X_train_raw, X_test_raw, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42
        )
        split_date = None
        
    # Fit preprocessor strictly on training data
    preprocessor = build_preprocessor_pipeline()
    X_train = preprocessor.fit_transform(X_train_raw)
    X_test = preprocessor.transform(X_test_raw)
    
    # Extract transformed feature names
    cat_encoder = preprocessor.named_transformers_["cat"]
    cat_names = list(cat_encoder.get_feature_names_out(CATEGORICAL_FEATURES))
    feature_names = NUMERICAL_FEATURES + cat_names
    
    return {
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test,
        "X_train_raw": X_train_raw,
        "X_test_raw": X_test_raw,
        "preprocessor": preprocessor,
        "feature_names": feature_names,
        "split_date": split_date,
        "df_clean": df_clean
    }

def prepare_classification_data(df, test_size=0.2, time_aware=True):
    """
    Prepares training and testing sets for Classification (predicting waste_risk_level: Low, Medium, High).
    """
    df_clean = clean_and_feature_engineer(df)
    
    # For classification, we use the contextual features
    # (attendance, previous demand, weather, menu, etc.)
    X = df_clean[ALL_FEATURE_COLS].copy()
    y = df_clean["waste_risk_level"].values
    
    n_samples = len(df_clean)
    if time_aware:
        split_idx = int(n_samples * (1 - test_size))
        X_train_raw = X.iloc[:split_idx]
        X_test_raw = X.iloc[split_idx:]
        y_train = y[:split_idx]
        y_test = y[split_idx:]
    else:
        from sklearn.model_selection import train_test_split
        X_train_raw, X_test_raw, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y
        )
        
    preprocessor = build_preprocessor_pipeline()
    X_train = preprocessor.fit_transform(X_train_raw)
    X_test = preprocessor.transform(X_test_raw)
    
    cat_encoder = preprocessor.named_transformers_["cat"]
    cat_names = list(cat_encoder.get_feature_names_out(CATEGORICAL_FEATURES))
    feature_names = NUMERICAL_FEATURES + cat_names
    
    return {
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test,
        "preprocessor": preprocessor,
        "feature_names": feature_names,
        "classes": ["Low", "Medium", "High"]
    }

def detect_outliers_iqr(series, threshold=1.5):
    """Computes IQR boundaries and identifies outlier indices."""
    q25 = series.quantile(0.25)
    q75 = series.quantile(0.75)
    iqr = q75 - q25
    lower_bound = q25 - threshold * iqr
    upper_bound = q75 + threshold * iqr
    outliers = series[(series < lower_bound) | (series > upper_bound)]
    return {
        "q25": round(float(q25), 2),
        "q75": round(float(q75), 2),
        "iqr": round(float(iqr), 2),
        "lower_bound": round(float(lower_bound), 2),
        "upper_bound": round(float(upper_bound), 2),
        "outlier_count": len(outliers),
        "outlier_indices": list(outliers.index)
    }

def get_data_quality_report(df_raw, df_processed):
    """
    Produces comprehensive data quality summary comparing raw input and processed dataset.
    """
    raw_missing = df_raw.isnull().sum().to_dict()
    processed_missing = df_processed.isnull().sum().to_dict()
    raw_duplicates = int(df_raw.duplicated().sum())
    
    # Outlier check on actual_meals_served & food_waste_kg if present
    outlier_info = {}
    if "actual_meals_served" in df_processed.columns:
        outlier_info["actual_meals_served"] = detect_outliers_iqr(df_processed["actual_meals_served"])
    if "food_waste_kg" in df_processed.columns:
        outlier_info["food_waste_kg"] = detect_outliers_iqr(df_processed["food_waste_kg"])
        
    return {
        "raw_shape": list(df_raw.shape),
        "processed_shape": list(df_processed.shape),
        "raw_duplicates": raw_duplicates,
        "raw_missing_columns": {k: int(v) for k, v in raw_missing.items() if v > 0},
        "processed_missing_columns": {k: int(v) for k, v in processed_missing.items() if v > 0},
        "outliers": outlier_info,
        "cleaning_operations": [
            "Removed duplicate rows",
            "Parsed and sorted chronological date timeline",
            "Imputed missing attendance values with campus baselines",
            "Constructed lag-1 demand ('prev_day_demand') and 7-day rolling average",
            "Calculated campus attendance and hostel resident density ratios",
            "Standardized categorical weather, menu, and event values",
            "Fitted StandardScaler and OneHotEncoder strictly on training splits"
        ]
    }
