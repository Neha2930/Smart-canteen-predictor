"""
Inference & Prediction Module for Smart Canteen Food Waste Predictor
Loads saved models and preprocessors to provide:
1. Real-time daily meal demand predictions with confidence buffers
2. Food-waste risk classification (Low, Medium, High)
3. Operational anomaly checking via Isolation Forest
4. Batch prediction on uploaded CSVs
"""

import os
import joblib
import numpy as np
import pandas as pd
import preprocessing

MODELS_DIR = os.path.join(os.path.dirname(__file__), "models")

# Cache models in memory
_MODELS_CACHE = {}

def get_loaded_models():
    """Loads all persisted models lazily and caches them in memory."""
    global _MODELS_CACHE
    if not _MODELS_CACHE:
        try:
            _MODELS_CACHE["preprocessor"] = joblib.load(os.path.join(MODELS_DIR, "preprocessor.joblib"))
            _MODELS_CACHE["best_regression"] = joblib.load(os.path.join(MODELS_DIR, "best_regression_model.joblib"))
            _MODELS_CACHE["linear_regression"] = joblib.load(os.path.join(MODELS_DIR, "linear_regression.joblib"))
            _MODELS_CACHE["rf_regression"] = joblib.load(os.path.join(MODELS_DIR, "random_forest_regression.joblib"))
            _MODELS_CACHE["best_classification"] = joblib.load(os.path.join(MODELS_DIR, "best_classification_model.joblib"))
            _MODELS_CACHE["kmeans"] = joblib.load(os.path.join(MODELS_DIR, "kmeans_clustering.joblib"))
            _MODELS_CACHE["cluster_scaler"] = joblib.load(os.path.join(MODELS_DIR, "cluster_scaler.joblib"))
            _MODELS_CACHE["isolation_forest"] = joblib.load(os.path.join(MODELS_DIR, "isolation_forest.joblib"))
            _MODELS_CACHE["anomaly_scaler"] = joblib.load(os.path.join(MODELS_DIR, "anomaly_scaler.joblib"))
            _MODELS_CACHE["decision_tree"] = joblib.load(os.path.join(MODELS_DIR, "decision_tree_regressor.joblib"))
        except Exception as e:
            print(f"Warning: Could not load some models: {e}. Retrain models if needed.")
    return _MODELS_CACHE

def validate_user_inputs(input_dict):
    """Validates raw user inputs to ensure safe and meaningful predictions."""
    errors = []
    
    # Campus attendance check
    attendance = input_dict.get("campus_attendance", 0)
    if not (100 <= attendance <= 10000):
        errors.append(f"Campus attendance ({attendance}) must be between 100 and 10,000 students/staff.")
        
    # Hostel residents check
    hostel = input_dict.get("hostel_residents_present", 0)
    if not (0 <= hostel <= attendance):
        errors.append(f"Hostel residents present ({hostel}) cannot exceed total campus attendance ({attendance}).")
        
    # Previous day demand check
    prev_demand = input_dict.get("prev_day_demand", 0)
    if prev_demand < 0 or prev_demand > 8000:
        errors.append(f"Previous day demand ({prev_demand}) must be a valid positive count up to 8,000.")
        
    # Temperature check
    temp = input_dict.get("temperature_c", 25.0)
    if not (5.0 <= temp <= 55.0):
        errors.append(f"Temperature ({temp}°C) is outside typical range (5°C to 55°C).")
        
    return errors

def predict_single_day(input_dict):
    """
    Computes meal demand, food waste risk, cluster assignment, and anomaly score
    for a single scheduled day's operational parameters.
    """
    errors = validate_user_inputs(input_dict)
    if errors:
        return {"success": False, "errors": errors}
        
    models = get_loaded_models()
    if not models or "best_regression" not in models:
        return {"success": False, "errors": ["Models are not yet loaded or trained. Please run train_models.py first."]}
        
    # Convert input to DataFrame
    df_raw = pd.DataFrame([input_dict])
    df_clean = preprocessing.clean_and_feature_engineer(df_raw)
    
    # Transform with saved preprocessor
    preprocessor = models["preprocessor"]
    X_transformed = preprocessor.transform(df_clean[preprocessing.ALL_FEATURE_COLS])
    
    # Regression prediction
    rf_pred = float(models["rf_regression"].predict(X_transformed)[0])
    lr_pred = float(models["linear_regression"].predict(X_transformed)[0])
    predicted_meals = round(rf_pred)
    
    # Recommendation logic
    # Base buffer: 5%
    buffer_pct = 0.05
    if input_dict.get("is_exam_period", 0) == 1 or input_dict.get("event_scheduled", "None") != "None":
        buffer_pct = 0.08
    elif input_dict.get("is_weekend", 0) == 1 or input_dict.get("is_holiday", 0) == 1:
        buffer_pct = 0.04
        
    recommended_prep = int(round(predicted_meals * (1 + buffer_pct)))
    buffer_meals = recommended_prep - predicted_meals
    
    # Classification prediction (Food-waste risk)
    risk_pred = str(models["best_classification"].predict(X_transformed)[0])
    risk_probs = models["best_classification"].predict_proba(X_transformed)[0]
    classes = list(models["best_classification"].classes_)
    risk_conf = {classes[i]: round(float(risk_probs[i] * 100), 1) for i in range(len(classes))}
    
    # Anomaly detection via Isolation Forest
    # Features: [actual_meals_served, meals_prepared, campus_attendance, food_waste_kg, waste_percentage]
    # For inference, assume chef planned based on naive +18% buffer to evaluate operational safety
    simulated_naive_prep = int(predicted_meals * 1.18)
    simulated_waste_kg = round(max(0, simulated_naive_prep - predicted_meals) * 0.42 + 12.0, 1)
    simulated_waste_pct = round((simulated_waste_kg / (simulated_naive_prep * 0.42 + 12.0)) * 100, 2)
    
    anom_raw = np.array([[predicted_meals, simulated_naive_prep, input_dict.get("campus_attendance", 2000), simulated_waste_kg, simulated_waste_pct]])
    anom_scaled = models["anomaly_scaler"].transform(anom_raw)
    anom_label = int(models["isolation_forest"].predict(anom_scaled)[0]) # 1 = normal, -1 = anomaly
    anom_score = round(float(models["isolation_forest"].decision_function(anom_scaled)[0]), 4)
    
    is_anomaly = True if anom_label == -1 else False
    
    # Comparison with 7-day rolling average or historical benchmark
    prev_demand = input_dict.get("prev_day_demand", predicted_meals)
    demand_diff = predicted_meals - prev_demand
    pct_change = round((demand_diff / (prev_demand + 1e-5)) * 100, 1)
    
    return {
        "success": True,
        "predicted_meals": predicted_meals,
        "rf_prediction": round(rf_pred, 1),
        "lr_prediction": round(lr_pred, 1),
        "recommended_preparation": recommended_prep,
        "buffer_meals": buffer_meals,
        "buffer_pct": int(buffer_pct * 100),
        "waste_risk_level": risk_pred,
        "risk_probabilities": risk_conf,
        "is_anomaly": is_anomaly,
        "anomaly_score": anom_score,
        "prev_day_demand": prev_demand,
        "demand_diff": demand_diff,
        "pct_change": pct_change,
        "estimated_waste_kg_if_optimized": round(buffer_meals * 0.42 + 8.0, 1),
        "estimated_waste_kg_if_unoptimized": simulated_waste_kg
    }

def batch_predict(df_raw):
    """
    Takes an uploaded CSV dataframe, validates required columns,
    and returns predictions for all rows.
    """
    models = get_loaded_models()
    if not models or "best_regression" not in models:
        raise ValueError("Machine learning models are not loaded. Train models before running batch predictions.")
        
    df_clean = preprocessing.clean_and_feature_engineer(df_raw)
    preprocessor = models["preprocessor"]
    
    X_transformed = preprocessor.transform(df_clean[preprocessing.ALL_FEATURE_COLS])
    
    # Predictions
    predicted_meals = np.round(models["best_regression"].predict(X_transformed)).astype(int)
    risk_levels = models["best_classification"].predict(X_transformed)
    
    # Recommended preparation
    recommended_prep = np.round(predicted_meals * 1.05).astype(int)
    
    df_results = df_raw.copy()
    df_results["predicted_meals_demanded"] = predicted_meals
    df_results["recommended_meals_prepared"] = recommended_prep
    df_results["predicted_waste_risk"] = risk_levels
    df_results["safety_buffer_meals"] = recommended_prep - predicted_meals
    
    return df_results
