"""
Visualization Module for Smart Canteen Food Waste Predictor
Generates rich, publication-grade interactive Plotly charts with
restrained, elegant color palettes (Emerald, Teal, Slate, Crimson, Amber).
"""

import plotly.express as px
import plotly.graph_objects as go
import numpy as np
import pandas as pd

# Elegant sustainability palette
COLOR_PRIMARY = "#059669"    # Emerald Green
COLOR_SECONDARY = "#0284c7"  # Ocean Blue
COLOR_ACCENT = "#f59e0b"     # Amber / Warning
COLOR_DANGER = "#e11d48"     # Rose / Crimson
COLOR_MUTED = "#64748b"      # Slate Grey
COLOR_DARK = "#0f172a"       # Slate 900
COLOR_BG_CARD = "#ffffff"

PLOT_TEMPLATE = "plotly_white"

def create_demand_trend_chart(df):
    """Interactive line chart of daily meals served with 7-day rolling average."""
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=df["date"],
        y=df["actual_meals_served"],
        mode="lines",
        name="Daily Demand (Meals)",
        line=dict(color="rgba(16, 185, 129, 0.4)", width=1.5),
        hovertemplate="<b>Date:</b> %{x}<br><b>Actual Demand:</b> %{y} meals<extra></extra>"
    ))
    
    if "rolling_avg_7d" in df.columns:
        fig.add_trace(go.Scatter(
            x=df["date"],
            y=df["rolling_avg_7d"],
            mode="lines",
            name="7-Day Moving Avg",
            line=dict(color="#047857", width=3),
            hovertemplate="<b>7-Day Trend:</b> %{y:.1f} meals<extra></extra>"
        ))
        
    fig.update_layout(
        title="<b>Daily Meal Demand Trends & 7-Day Moving Average</b>",
        xaxis_title="Date",
        yaxis_title="Total Meals Served",
        template=PLOT_TEMPLATE,
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40)
    )
    return fig

def create_actual_vs_predicted_chart(pred_df):
    """Compares Actual Demand with Linear Regression and Random Forest test predictions."""
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=pred_df["date"],
        y=pred_df["actual_demand"],
        mode="lines+markers",
        name="Actual Ground Truth",
        marker=dict(size=6, color="#0f172a"),
        line=dict(color="#0f172a", width=2),
        hovertemplate="<b>Actual:</b> %{y} meals<extra></extra>"
    ))
    
    fig.add_trace(go.Scatter(
        x=pred_df["date"],
        y=pred_df["random_forest_pred"],
        mode="lines",
        name="Random Forest Regressor",
        line=dict(color="#059669", width=2.5, dash="solid"),
        hovertemplate="<b>Random Forest:</b> %{y} meals<extra></extra>"
    ))
    
    fig.add_trace(go.Scatter(
        x=pred_df["date"],
        y=pred_df["linear_regression_pred"],
        mode="lines",
        name="Linear Regression",
        line=dict(color="#0284c7", width=1.8, dash="dot"),
        hovertemplate="<b>Linear Reg:</b> %{y} meals<extra></extra>"
    ))
    
    fig.update_layout(
        title="<b>Model Evaluation: Actual vs Predicted Demand on Holdout Test Set</b>",
        xaxis_title="Test Evaluation Date",
        yaxis_title="Number of Meals",
        template=PLOT_TEMPLATE,
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40)
    )
    return fig

def create_waste_trends_chart(df):
    """Visualizes measured food waste in kilograms and waste percentage."""
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=df["date"],
        y=df["food_waste_kg"],
        name="Food Waste (kg)",
        marker_color="#f43f5e",
        opacity=0.75,
        hovertemplate="<b>Date:</b> %{x}<br><b>Waste:</b> %{y:.1f} kg<extra></extra>"
    ))
    
    if "waste_percentage" in df.columns:
        fig.add_trace(go.Scatter(
            x=df["date"],
            y=df["waste_percentage"],
            name="Waste Percentage (%)",
            yaxis="y2",
            mode="lines",
            line=dict(color="#d97706", width=2),
            hovertemplate="<b>Waste Ratio:</b> %{y:.1f}%<extra></extra>"
        ))
        
    fig.update_layout(
        title="<b>Daily Food Waste (kg) and Waste Ratio Dynamics</b>",
        xaxis_title="Date",
        yaxis_title="Food Waste (kg)",
        yaxis2=dict(
            title="Waste Percentage (%)",
            overlaying="y",
            side="right",
            range=[0, 45],
            showgrid=False
        ),
        template=PLOT_TEMPLATE,
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40)
    )
    return fig

def create_model_comparison_bar(reg_comparison):
    """Bar chart comparing Linear Regression vs Random Forest on MAE, RMSE, and R2."""
    models = ["Linear Regression", "Random Forest Regressor"]
    mae_vals = [reg_comparison["Linear Regression"]["MAE"], reg_comparison["Random Forest Regressor"]["MAE"]]
    rmse_vals = [reg_comparison["Linear Regression"]["RMSE"], reg_comparison["Random Forest Regressor"]["RMSE"]]
    r2_vals = [reg_comparison["Linear Regression"]["R2"] * 100, reg_comparison["Random Forest Regressor"]["R2"] * 100]
    
    fig = go.Figure(data=[
        go.Bar(name="MAE (Lower is Better)", x=models, y=mae_vals, marker_color="#38bdf8", text=mae_vals, textposition="auto"),
        go.Bar(name="RMSE (Lower is Better)", x=models, y=rmse_vals, marker_color="#818cf8", text=rmse_vals, textposition="auto"),
        go.Bar(name="R² Score % (Higher is Better)", x=models, y=r2_vals, marker_color="#34d399", text=[f"{v:.1f}%" for v in r2_vals], textposition="auto")
    ])
    
    fig.update_layout(
        title="<b>Regression Model Performance Benchmark (MAE, RMSE, R²)</b>",
        barmode="group",
        yaxis_title="Metric Value",
        template=PLOT_TEMPLATE,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40)
    )
    return fig

def create_confusion_matrix_heatmap(cm, classes):
    """Heatmap of the classification confusion matrix."""
    cm_text = [[str(val) for val in row] for row in cm]
    
    fig = go.Figure(data=go.Heatmap(
        z=cm,
        x=[f"Pred {c}" for c in classes],
        y=[f"True {c}" for c in classes],
        text=cm_text,
        texttemplate="%{text}",
        textfont={"size": 16, "color": "white"},
        colorscale="Blues",
        showscale=True
    ))
    
    fig.update_layout(
        title="<b>Confusion Matrix: Food-Waste Risk Classification</b>",
        xaxis_title="Predicted Waste Risk Level",
        yaxis_title="Actual Ground-Truth Risk Level",
        template=PLOT_TEMPLATE,
        margin=dict(l=50, r=50, t=60, b=50)
    )
    return fig

def create_classification_metrics_bar(cls_report, classes=["Low", "Medium", "High"]):
    """Compares Precision, Recall, and F1-Score across classes."""
    precision = [round(cls_report[c]["precision"] * 100, 1) for c in classes]
    recall = [round(cls_report[c]["recall"] * 100, 1) for c in classes]
    f1 = [round(cls_report[c]["f1-score"] * 100, 1) for c in classes]
    
    fig = go.Figure(data=[
        go.Bar(name="Precision (%)", x=classes, y=precision, marker_color="#0284c7", text=[f"{p}%" for p in precision], textposition="auto"),
        go.Bar(name="Recall (%)", x=classes, y=recall, marker_color="#059669", text=[f"{r}%" for r in recall], textposition="auto"),
        go.Bar(name="F1-Score (%)", x=classes, y=f1, marker_color="#d97706", text=[f"{f}%" for f in f1], textposition="auto")
    ])
    
    fig.update_layout(
        title="<b>Class-Wise Performance: Precision, Recall & F1-Score</b>",
        barmode="group",
        yaxis_title="Percentage (%)",
        yaxis_range=[0, 105],
        template=PLOT_TEMPLATE,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40)
    )
    return fig

def create_kmeans_scatter(df):
    """Interactive 2D scatter plot of K-Means clusters with hover details."""
    cluster_color_map = {
        0: "#3b82f6",  # Blue
        1: "#10b981",  # Green
        2: "#f59e0b"   # Amber
    }
    
    fig = px.scatter(
        df,
        x="campus_attendance",
        y="actual_meals_served",
        color="cluster_name" if "cluster_name" in df.columns else "cluster",
        size="food_waste_kg" if "food_waste_kg" in df.columns else None,
        hover_data=["day_of_week", "weather_condition", "menu_specialty", "food_waste_kg"],
        title="<b>K-Means Clusters: Campus Attendance vs Actual Meal Demand</b>",
        labels={
            "campus_attendance": "Campus Attendance (Students & Staff)",
            "actual_meals_served": "Actual Meals Demanded",
            "cluster_name": "Consumption Pattern",
            "food_waste_kg": "Waste (kg)"
        },
        template=PLOT_TEMPLATE
    )
    fig.update_layout(
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40)
    )
    return fig

def create_elbow_chart(k_range, inertias, optimal_k=3):
    """Elbow curve visualization showing Sum of Squared Distances vs K."""
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=k_range,
        y=inertias,
        mode="lines+markers",
        name="Inertia (Within-Cluster Sum of Squares)",
        line=dict(color="#4f46e5", width=3),
        marker=dict(size=9, color="#4f46e5")
    ))
    
    # Highlight optimal K
    optimal_idx = k_range.index(optimal_k) if optimal_k in k_range else 1
    fig.add_trace(go.Scatter(
        x=[optimal_k],
        y=[inertias[optimal_idx]],
        mode="markers+text",
        name=f"Optimal Elbow (K={optimal_k})",
        text=[f"Optimal K={optimal_k}"],
        textposition="top right",
        marker=dict(size=14, color="#ef4444", symbol="star")
    ))
    
    fig.update_layout(
        title="<b>K-Means Elbow Method: Inertia vs Number of Clusters (K)</b>",
        xaxis_title="Number of Clusters (K)",
        yaxis_title="Inertia (Sum of Squared Distances)",
        template=PLOT_TEMPLATE,
        margin=dict(l=40, r=40, t=60, b=40)
    )
    return fig

def create_feature_importance_chart(feature_importances, top_n=10):
    """Horizontal bar chart showing top feature importances from Random Forest."""
    top_features = feature_importances[:top_n]
    names = [f["feature"] for f in top_features][::-1]
    scores = [round(f["importance"] * 100, 2) for f in top_features][::-1]
    
    fig = go.Figure(go.Bar(
        x=scores,
        y=names,
        orientation="h",
        marker=dict(
            color=scores,
            colorscale="Viridis",
            showscale=False
        ),
        text=[f"{s:.1f}%" for s in scores],
        textposition="outside"
    ))
    
    fig.update_layout(
        title=f"<b>Top {top_n} Key Features Driving Daily Food Demand (Feature Importance)</b>",
        xaxis_title="Relative Importance Weight (%)",
        yaxis_title="Feature Name",
        template=PLOT_TEMPLATE,
        margin=dict(l=150, r=50, t=60, b=40)
    )
    return fig

def create_anomaly_scatter_chart(df):
    """Plots operational points highlighting anomalies detected by Isolation Forest."""
    fig = go.Figure()
    
    normal_df = df[~df["is_anomaly"]]
    anom_df = df[df["is_anomaly"]]
    
    fig.add_trace(go.Scatter(
        x=normal_df["campus_attendance"],
        y=normal_df["actual_meals_served"],
        mode="markers",
        name="Normal Operation",
        marker=dict(size=7, color="#059669", opacity=0.6),
        hovertemplate="<b>Attendance:</b> %{x}<br><b>Demand:</b> %{y}<br><b>Status:</b> Normal<extra></extra>"
    ))
    
    fig.add_trace(go.Scatter(
        x=anom_df["campus_attendance"],
        y=anom_df["actual_meals_served"],
        mode="markers",
        name="Detected Anomaly (Isolation Forest)",
        marker=dict(size=12, color="#e11d48", symbol="diamond-dot", line=dict(width=2, color="#881337")),
        hovertemplate="<b>Attendance:</b> %{x}<br><b>Demand:</b> %{y}<br><b>Anomaly Score:</b> %{text}<br><b>Status:</b> Unusual Event<extra></extra>",
        text=anom_df["anomaly_score"] if "anomaly_score" in anom_df.columns else ["Anomaly"] * len(anom_df)
    ))
    
    fig.update_layout(
        title="<b>Isolation Forest Anomaly Detection (Attendance vs Meal Demand)</b>",
        xaxis_title="Campus Attendance",
        yaxis_title="Actual Meals Served",
        template=PLOT_TEMPLATE,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40)
    )
    return fig
