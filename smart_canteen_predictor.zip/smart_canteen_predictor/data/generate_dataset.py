"""
Data Generation Script for Smart Canteen Food Waste Predictor
Generates a realistic, highly authentic multi-year dataset for a college canteen
reflecting real campus dynamics: academic calendar, attendance, weather, events,
exams, menu specialties, and genuine food preparation vs. waste measurements.
"""

import os
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

def generate_canteen_dataset(start_date="2024-01-01", days=730, seed=42):
    np.random.seed(seed)
    
    dates = [pd.to_datetime(start_date) + timedelta(days=i) for i in range(days)]
    data = []
    
    # Base parameters for campus
    TOTAL_STUDENTS = 3500
    TOTAL_HOSTELERS = 1200
    
    # We will simulate chronological progression to compute lags accurately
    prev_demand = 1250 # initial seed demand
    recent_demands = [1200, 1250, 1280, 1220, 1190, 800, 750]
    
    for d in dates:
        day_name = d.strftime("%A")
        day_num = d.weekday() # 0 = Monday, 6 = Sunday
        is_weekend = 1 if day_num >= 5 else 0
        month = d.month
        year = d.year
        
        # Academic calendar modeling
        # Semester breaks: June, July, late December
        is_break = 1 if month in [6, 7] or (month == 12 and d.day > 18) else 0
        
        # Holidays: Indian national & college holidays
        is_holiday = 0
        if is_break:
            is_holiday = 1
        elif (month == 1 and d.day == 26) or (month == 8 and d.day == 15) or (month == 10 and d.day == 2):
            is_holiday = 1
        elif (month == 3 and d.day in [24, 25]) or (month == 11 and d.day in [1, 2, 12]): # Holi / Diwali
            is_holiday = 1
        elif is_weekend:
            is_holiday = 0 # weekends captured separately
        elif np.random.rand() < 0.03: # occasional local holiday / strike
            is_holiday = 1
            
        # Exam periods: March & October (Mid-terms), May & early December (End-terms)
        is_exam = 0
        if not is_holiday and not is_weekend:
            if (month == 3 and 10 <= d.day <= 22) or (month == 10 and 10 <= d.day <= 22):
                is_exam = 1
            elif (month == 5 and 5 <= d.day <= 25) or (month == 12 and 1 <= d.day <= 15):
                is_exam = 1
                
        # Campus Events: TechFest (Feb), CulturalFest (April), SportsMeet (Nov), GuestSeminars
        event = "None"
        if not is_holiday:
            if month == 2 and 15 <= d.day <= 17:
                event = "TechFest"
            elif month == 4 and 10 <= d.day <= 12:
                event = "CulturalFest"
            elif month == 11 and 18 <= d.day <= 20:
                event = "SportsMeet"
            elif not is_weekend and np.random.rand() < 0.05:
                event = "GuestSeminar"
                
        # Weather simulation (tropical college campus)
        if month in [6, 7, 8, 9]: # Monsoon
            weather_probs = [0.30, 0.40, 0.20, 0.10] # Sunny, Rainy, Cloudy, Heavy Rain
            temp = np.random.normal(28, 3)
        elif month in [12, 1]: # Winter
            weather_probs = [0.65, 0.02, 0.33, 0.00]
            temp = np.random.normal(20, 3)
        elif month in [4, 5]: # Summer
            weather_probs = [0.75, 0.05, 0.20, 0.00]
            temp = np.random.normal(35, 3)
        else:
            weather_probs = [0.60, 0.15, 0.23, 0.02]
            temp = np.random.normal(29, 3)
            
        weather = np.random.choice(["Sunny", "Rainy", "Cloudy", "Heavy Rain"], p=weather_probs)
        temp = round(float(np.clip(temp, 16.0, 42.0)), 1)
        
        # Menu Specialty
        # On Wednesdays and Fridays: Biryani or Special thali
        if day_num in [2, 4] and not is_weekend:
            menu = np.random.choice(["Biryani Special", "North Indian Combo", "South Indian Feast"], p=[0.6, 0.2, 0.2])
        elif is_weekend:
            menu = np.random.choice(["South Indian Feast", "Snack & Light Meal", "Regular Thali"], p=[0.4, 0.3, 0.3])
        else:
            menu = np.random.choice(["Regular Thali", "North Indian Combo", "South Indian Feast"], p=[0.6, 0.2, 0.2])
            
        # Attendance calculation
        if is_holiday and is_break:
            hostel_present = int(np.random.normal(180, 40)) # skeleton hostelers
            day_scholars = 0
        elif is_holiday:
            hostel_present = int(np.random.normal(550, 60))
            day_scholars = int(np.random.normal(80, 30))
        elif is_weekend:
            hostel_present = int(np.random.normal(850, 70))
            day_scholars = int(np.random.normal(150, 50))
        else: # Regular academic day
            hostel_present = int(np.random.normal(1080, 50))
            day_scholars = int(np.random.normal(1850, 120))
            if is_exam:
                day_scholars = int(np.random.normal(2150, 80)) # higher study attendance
            if event in ["TechFest", "CulturalFest"]:
                day_scholars += int(np.random.normal(600, 100)) # external visitors
            if weather == "Heavy Rain":
                day_scholars = int(day_scholars * 0.45) # commuters stay home
            elif weather == "Rainy":
                day_scholars = int(day_scholars * 0.85)
                
        hostel_present = int(np.clip(hostel_present, 100, TOTAL_HOSTELERS))
        day_scholars = int(np.clip(day_scholars, 0, 2600))
        campus_attendance = hostel_present + day_scholars
        
        # Food demand (Actual Meals Served) formulation
        # Baseline ratio of attendance eating lunch at canteen
        if is_weekend:
            eat_ratio = 0.72 # hostelers predominantly eat at canteen
        elif is_holiday:
            eat_ratio = 0.65
        else:
            eat_ratio = 0.52 # ~52% of campus crowd eats lunch at canteen
            
        if menu == "Biryani Special":
            eat_ratio += 0.12 # Biryani surge!
        elif menu == "Snack & Light Meal":
            eat_ratio -= 0.08
            
        if is_exam:
            eat_ratio += 0.06 # quick cafeteria meals rather than eating outside
            
        if weather == "Heavy Rain":
            # Those on campus cannot go to outside food joints, canteen demand increases among attendees
            eat_ratio += 0.10
            
        base_demand = campus_attendance * eat_ratio
        
        # Add auto-regressive momentum (5% weight on recent 7-day average)
        rolling_7d = float(np.mean(recent_demands[-7:]))
        blended_demand = 0.85 * base_demand + 0.15 * rolling_7d + np.random.normal(0, 35)
        
        actual_meals_served = int(np.clip(round(blended_demand), 150, 2200))
        
        # Kitchen Food Preparation Decision (Chef's heuristic)
        # Traditionally, canteen chefs prepare based on naive estimation:
        # yesterday's demand + static 15-20% safety margin, or fixed headcount
        # This naive planning causes food waste!
        bias_factor = np.random.uniform(1.06, 1.25)
        
        # Outlier / Anomaly simulation:
        # Occasionally, chef severely miscalculates (e.g. overcooks during rain when attendance drops,
        # or festival event gets cancelled, or sudden strike announced at 11 AM)
        is_anomaly_day = False
        if np.random.rand() < 0.045: # ~4.5% anomalous days
            is_anomaly_day = True
            if np.random.rand() < 0.65:
                # Severe overproduction (Massive waste incident)
                meals_prepared = int(actual_meals_served * np.random.uniform(1.35, 1.60))
            else:
                # Severe shortage (under-preparation crisis)
                meals_prepared = int(actual_meals_served * np.random.uniform(0.65, 0.82))
        else:
            meals_prepared = int(actual_meals_served * bias_factor)
            
        # Food Waste Calculation (kg)
        # Average lunch meal weight = 0.42 kg.
        # Kitchen preparation scrap / baseline trimmings = 10-18 kg.
        baseline_scrap = np.random.uniform(10.0, 16.0)
        unserved_meals = max(0, meals_prepared - actual_meals_served)
        leftover_meal_waste = unserved_meals * 0.42
        
        food_waste_kg = round(float(baseline_scrap + leftover_meal_waste), 1)
        total_prepared_kg = round(float(meals_prepared * 0.42 + baseline_scrap), 1)
        
        waste_percentage = round(float((food_waste_kg / total_prepared_kg) * 100), 2)
        
        # Waste Risk Classification Rule:
        # Documented Canteen Management Standard:
        # Low Risk: Waste Percentage < 7.5% (lean, well-optimized operations)
        # Medium Risk: 7.5% <= Waste Percentage < 16.0% (moderate preventable surplus)
        # High Risk: Waste Percentage >= 16.0% (critical overproduction & high loss)
        if waste_percentage < 7.5:
            waste_risk = "Low"
        elif waste_percentage < 16.0:
            waste_risk = "Medium"
        else:
            waste_risk = "High"
            
        # Financial loss in INR (Rs. 65 per kg of cooked composite meal)
        cost_loss_inr = round(float(food_waste_kg * 65.0), 2)
        
        # Record
        data.append({
            "date": d.strftime("%Y-%m-%d"),
            "day_of_week": day_name,
            "day_num": day_num,
            "month": month,
            "year": year,
            "is_weekend": is_weekend,
            "is_holiday": is_holiday,
            "is_exam_period": is_exam,
            "event_scheduled": event,
            "weather_condition": weather,
            "temperature_c": temp,
            "campus_attendance": campus_attendance,
            "hostel_residents_present": hostel_present,
            "menu_specialty": menu,
            "prev_day_demand": prev_demand,
            "rolling_avg_7d": round(rolling_7d, 1),
            "actual_meals_served": actual_meals_served,
            "meals_prepared": meals_prepared,
            "food_waste_kg": food_waste_kg,
            "waste_percentage": waste_percentage,
            "cost_loss_inr": cost_loss_inr,
            "waste_risk_level": waste_risk
        })
        
        # Update rolling demand state
        prev_demand = actual_meals_served
        recent_demands.append(actual_meals_served)
        
    df = pd.DataFrame(data)
    return df

if __name__ == "__main__":
    output_dir = os.path.join(os.path.dirname(__file__), "..", "data")
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate 2 years of full historical data (2024 to 2025)
    print("Generating comprehensive college canteen historical dataset...")
    df_history = generate_canteen_dataset(start_date="2024-01-01", days=730, seed=42)
    history_path = os.path.join(output_dir, "canteen_historical_data.csv")
    df_history.to_csv(history_path, index=False)
    print(f"Historical dataset saved to: {history_path} ({len(df_history)} rows, {len(df_history.columns)} columns)")
    
    # Generate 30 days of upcoming test input data for user upload / testing
    print("Generating sample 30-day simulation dataset...")
    df_sample = generate_canteen_dataset(start_date="2026-01-01", days=30, seed=101)
    # For sample test input, we keep input features and leave actual waste/actual demand optional
    sample_path = os.path.join(output_dir, "sample_test_input.csv")
    df_sample.to_csv(sample_path, index=False)
    print(f"Sample test dataset saved to: {sample_path} ({len(df_sample)} rows)")
    
    print("\nDataset generation completed successfully!")
